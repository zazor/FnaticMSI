import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.concurrent.TimeUnit;

import static com.thoughtworks.selenium.SeleneseTestNgHelper.assertEquals;



/**
 * Created by Administrator on 22.8.2015 �..
 */
public class LoginAsManager {
    private WebDriver driver;

    @Before
    public void SetUp() {
        driver = new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


    }

    @Test
    public void TestLogin() {

        String userName = "TestManager";
        String password = "123456789";

        driver.get("http://localhost/fnaticmsi");
        WebElement usernameField = driver.findElement(By.id("LoginForm_username"));
        usernameField.sendKeys(userName);

        WebElement passwordField = driver.findElement(By.id("LoginForm_password"));
        passwordField.sendKeys(password);

        WebElement loginButton = driver.findElement(By.xpath("/html/body/div/div/div[2]/form/div[4]/div[1]/input"));
        loginButton.click();

        WebElement dropDown = driver.findElement(By.cssSelector("span.hidden-small"));
        dropDown.click();

        WebElement viewProfileButton = driver.findElement(By.linkText("View Profile"));
        viewProfileButton.click();

        WebElement firstName = driver.findElement(By.cssSelector("h3.profile-title"));
        assertEquals("TestMFN TestMLN", firstName.getText());

        WebElement managerUsername = driver.findElement(By.cssSelector("dd"));
        assertEquals("TestManager", managerUsername.getText());

        WebElement Game = driver.findElement(By.xpath("/html/body/div/div[2]/section/div[2]/div/div/div[2]/div/div/dl/dd[2]"));
        assertEquals("Starcraft II", Game.getText());

        WebElement gameGenre = driver.findElement(By.xpath("/html/body/div/div[2]/section/div[2]/div/div/div[2]/div/div/dl/dd[3]"));
        assertEquals("MOBA", gameGenre.getText());

        WebElement City = driver.findElement(By.xpath("/html/body/div/div[2]/section/div[2]/div/div/div[2]/div/div/dl/dd[4]"));
        assertEquals("TestMC", City.getText());

        WebElement Address = driver.findElement(By.xpath("/html/body/div/div[2]/section/div[2]/div/div/div[2]/div/div/dl/dd[5]"));
        assertEquals("TestMA", Address.getText());


    }
    @After
    public void tearDown() {

    }
}