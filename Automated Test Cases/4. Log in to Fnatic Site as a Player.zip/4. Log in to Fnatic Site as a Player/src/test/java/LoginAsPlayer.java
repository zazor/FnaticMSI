import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.concurrent.TimeUnit;

import static com.thoughtworks.selenium.SeleneseTestNgHelper.assertEquals;

/**
 * Created by Administrator on 22.8.2015 �..
 */
public class LoginAsPlayer {
    private WebDriver driver;

    @Before
    public void SetUp() {
        driver = new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


    }
    @Test
    public void TestLogin() {

        String userName = "TestUser2";
        String password = "123456789";

        driver.get("http://localhost/fnaticmsi");
        WebElement usernameField = driver.findElement(By.id("LoginForm_username"));
        usernameField.sendKeys(userName);

        WebElement passwordField = driver.findElement(By.id("LoginForm_password"));
        passwordField.sendKeys(password);

        WebElement loginButton = driver.findElement(By.xpath("/html/body/div/div/div[2]/form/div[4]/div[1]/input"));
        loginButton.click();

        WebElement usernameColumn = driver.findElement(By.xpath("//td[2]"));
        assertEquals("TestUser2", usernameColumn.getText());

        WebElement firstNameColumn = driver.findElement(By.xpath("//td[3]"));
        assertEquals("TestFN", firstNameColumn.getText());

        WebElement nickNameColumn = driver.findElement(By.xpath("//td[4]"));
        assertEquals("TestNN", nickNameColumn.getText());

        WebElement lastNameColumn = driver.findElement(By.xpath("//td[5]"));
        assertEquals("TestLN", lastNameColumn.getText());

        WebElement salaryColumn = driver.findElement(By.xpath("//td[6]"));
        assertEquals("9000.0000", salaryColumn.getText());

        WebElement addressColumn = driver.findElement(By.xpath("//td[7]"));
        assertEquals("TestAddress", addressColumn.getText());

        WebElement cityColumn = driver.findElement(By.xpath("//td[8]"));
        assertEquals("TestCity", cityColumn.getText());


    }
    @After
    public void tearDown() {

    }
}