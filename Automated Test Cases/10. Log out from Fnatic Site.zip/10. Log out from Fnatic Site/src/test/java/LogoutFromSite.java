import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.concurrent.TimeUnit;

import static com.thoughtworks.selenium.SeleneseTestNgHelper.assertEquals;


/**
 * Created by Administrator on 22.8.2015 �..
 */
public class LogoutFromSite {

    private WebDriver driver;

    @Before
    public void SetUp() {
        driver = new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


    }

    @Test
    public void TestLogin() {

        String userName = "TestUser2";
        String password = "123456789";

        driver.get("http://localhost/fnaticmsi");
        WebElement usernameField = driver.findElement(By.id("LoginForm_username"));
        usernameField.sendKeys(userName);

        WebElement passwordField = driver.findElement(By.id("LoginForm_password"));
        passwordField.sendKeys(password);

        WebElement loginButton = driver.findElement(By.xpath("/html/body/div/div/div[2]/form/div[4]/div[1]/input"));
        loginButton.click();

        WebElement dropDown = driver.findElement(By.cssSelector("span.hidden-small"));
        dropDown.click();

        WebElement logoutButton = driver.findElement(By.linkText("Logout"));
        logoutButton.click();

        assertEquals("http://localhost/fnaticmsi/", driver.getCurrentUrl());


    }
    @After
    public void tearDown() {

    }
}